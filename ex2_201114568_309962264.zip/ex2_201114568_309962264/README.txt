Accoding to the answers in the forum -

Test 0 from the testers of excersice 1 had been changed, to the following:
In case, after positioning on board has been done and no players have moving tools - we declare a tie 
(a new reason had been formulated to match the case)

In case, while playing the game, one of the players doesn't have any moving tools, 
a player who doesn't have a legal move looses the game, also if the other player doesn't have a legal move.
the reason is: Bad Moves input for player X

In case, while playing the game, both players don't have any moving tools, the player who it is his turn
to move, looses the game and the reason would be: All moving PIECEs of the opponent are eaten

